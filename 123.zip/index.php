<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>eBooks - a sua livraria on line</title>
<link href="imagens/logoicon.png" rel="icon">
<link rel="stylesheet" href="css/estilo.css">
<script src="js/jquery-3.3.1.min.js"></script>
<link href="slick/slick-theme.css" rel="stylesheet">
<link href="slick/slick.css" rel="stylesheet">
<script src="slick/slick.min.js"></script>
<script src="js/script.js"></script>
</head>

<body>
	<?php include_once("nav.php");?>
	<?php include_once("banner.php");?>
	<section id="corpo"></section>
	<?php include_once("footer.php");?>
</body>
</html>
