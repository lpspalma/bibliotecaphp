<nav>
	<a href="index.php"><img src="imagens/logo.jpg"></a>
	<span>
		<a href="index.php">Home</a>
		<a href="#">Nacional</a>
		<a href="#">Estrangeiro</a>
		<a href="#">Best Seller</a>
		<a href="#">Lançamentos</a>
		<a href="#">Didáticos</a>
		<a href="#">Fale Conosco</a>
	</span>
</nav>