<footer>
	<div class="formulario">
		<form method="post" action="envia.php">
			<input type="text" name="fnome" required placeholder="Seu Nome" class="campo">
			<input type="email" name="femail" required placeholder="Seu Melhor E-mail" class="campo">
			<input type="text" name="fassunto" required placeholder="Assunto" class="campo">
			<textarea name="fmsg" placeholder="Sua Mensagem" rows="7" required class="campo"></textarea>
			<input type="submit" value="Enviar" class="botao">
		</form>
	</div>
	<div class="mapa">
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3603.1069087382416!2d-49.27803468539966!3d-25.43468908378619!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94dce4725815a121%3A0x4df479f0b66b346b!2sRua+Visconde+de+N%C3%A1car%2C+1455+-+Centro%2C+Curitiba+-+PR%2C+80410-201!5e0!3m2!1spt-BR!2sbr!4v1534374981763" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
	</div>
</footer>