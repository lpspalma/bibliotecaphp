// JavaScript Document
$(document).ready(function(){
	$(".slide").slick({
		autoplay:true,
		autoplaySpeed:1000,
		dots:true
	})
})