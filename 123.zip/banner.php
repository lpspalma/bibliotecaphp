<header>
	<div class="slide">
		<div><img src="banners/banner1.jpg"></div>
		<div><img src="banners/banner2.jpg"></div>
		<div><img src="banners/banner3.jpg"></div>
	</div>
</header>